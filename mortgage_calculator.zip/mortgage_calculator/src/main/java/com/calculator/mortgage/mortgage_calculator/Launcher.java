package com.calculator.mortgage.mortgage_calculator;

public class Launcher {
    public static void main(String[] args) {
        new MortgageApplication().begin();
    }
}
