package com.calculator.mortgage.data;

public enum loanType {
    LINEAR,
    ANNUITY
}
